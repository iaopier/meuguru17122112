#include "produto.hpp"

int Produto::getQtd() const {
  return this->getQtd();
}

float Produto::getValor() const {
  return this->getValor();
}

